/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.projet.gestionfacture.dao;

import com.projet.gestionfacture.models.Fournisseur;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EntityManager;

/**
 *
 * @author Cimanuka
 */
public class FournisseurDao {
    
    public void save(Fournisseur f){
        EntityManager em = HibernateUtil.getEntityManager();
        em.getTransaction().begin();
        em.merge(f);
        em.getTransaction().commit();
        em.close();
    }
    public List<Fournisseur> getAll(){
        EntityManager em = HibernateUtil.getEntityManager();
        return em.createQuery("from Fournisseur",Fournisseur.class).getResultList();
    }
    public void delete(Fournisseur f){
        EntityManager em = HibernateUtil.getEntityManager();
        em.getTransaction().begin();
        em.remove(em.merge(f));
        em.getTransaction().commit();
        em.close();
    }
    public Fournisseur findById(Long id){
        EntityManager em = HibernateUtil.getEntityManager();
        Fournisseur f = em.find(Fournisseur.class, id);
        em.close();
        return f;
    }
}
