package com.projet.gestionfacture;

import com.projet.gestionfacture.dao.CategorieDao;
import com.projet.gestionfacture.dao.FournisseurDao;
import com.projet.gestionfacture.dao.ProduitDao;
import com.projet.gestionfacture.models.Categorie;
import com.projet.gestionfacture.models.Fournisseur;
import com.projet.gestionfacture.models.Produit;
import java.io.IOException;
import java.util.Date;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

public class PrimaryController {

    private final CategorieDao categorieDao = new CategorieDao();
    private final ProduitDao produitDao = new ProduitDao();
    private final FournisseurDao fournisseurDao = new FournisseurDao();
    
    @FXML
    private AnchorPane panelcentral;
    @FXML
    private Pane panefacture;
    @FXML
    private Pane panecmd;
    @FXML
    private Pane paneclient;
    @FXML
    private Pane panefournisseur;
    @FXML
    private Pane paneproduit;
    @FXML
    private Pane panecat;
    @FXML
    private Pane panestock;
    
    @FXML
    private void openFactureContent() throws IOException{
      Parent parent = FXMLLoader.load(getClass()
                .getResource("basefacture.fxml"));
      panelcentral.getChildren().setAll(parent);
      panefacture.setStyle("-fx-background-color:#ffffff;");
      panecmd.setStyle("-fx-background-color:#6fddbd");
      paneclient.setStyle("-fx-background-color:#6fddbd");
      panefournisseur.setStyle("-fx-background-color:#6fddbd");
      paneproduit.setStyle("-fx-background-color:#6fddbd");
      panecat.setStyle("-fx-background-color:#6fddbd");
      panestock.setStyle("-fx-background-color:#6fddbd");

      System.out.println("Click sur bouton open facture");   
    }
    @FXML
    private void openCmdContent() throws IOException{
      Parent parent = FXMLLoader.load(getClass()
                .getResource("basecmd.fxml"));
      panelcentral.getChildren().setAll(parent);
      
      panefacture.setStyle("-fx-background-color:#6fddbd;");
      panecmd.setStyle("-fx-background-color:#ffffff");
      paneclient.setStyle("-fx-background-color:#6fddbd");
      panefournisseur.setStyle("-fx-background-color:#6fddbd");
      paneproduit.setStyle("-fx-background-color:#6fddbd");
      panecat.setStyle("-fx-background-color:#6fddbd");
      panestock.setStyle("-fx-background-color:#6fddbd");
      
      System.out.println("Click sur bouton open cmd"); 
    }
    @FXML
    private void openClientContent()throws IOException{
      Parent parent = FXMLLoader.load(getClass()
             .getResource("baseclient.fxml"));
      panelcentral.getChildren().setAll(parent);
      
      panefacture.setStyle("-fx-background-color:#6fddbd;");
      panecmd.setStyle("-fx-background-color:#6fddbd");
      paneclient.setStyle("-fx-background-color:#ffffff");
      panefournisseur.setStyle("-fx-background-color:#6fddbd");
      paneproduit.setStyle("-fx-background-color:#6fddbd");
      panecat.setStyle("-fx-background-color:#6fddbd");
      panestock.setStyle("-fx-background-color:#6fddbd");
      
      System.out.println("Click sur bouton open client"); 
    }
    @FXML
    private void openFournisseurContent() throws IOException{
      Parent parent = FXMLLoader.load(getClass()
             .getResource("basefournisseur.fxml"));
      panelcentral.getChildren().setAll(parent);
      
      panefacture.setStyle("-fx-background-color:#6fddbd;");
      panecmd.setStyle("-fx-background-color:#6fddbd");
      paneclient.setStyle("-fx-background-color:#6fddbd");
      panefournisseur.setStyle("-fx-background-color:#ffffff");
      paneproduit.setStyle("-fx-background-color:#6fddbd");
      panecat.setStyle("-fx-background-color:#6fddbd");
      panestock.setStyle("-fx-background-color:#6fddbd");
      
      System.out.println("Click sur bouton open fournisseur"); 
    }
    @FXML
    private void openProdContent()throws IOException{
      Parent parent = FXMLLoader.load(getClass()
             .getResource("baseproduit.fxml"));
      panelcentral.getChildren().setAll(parent);
     
      panefacture.setStyle("-fx-background-color:#6fddbd;");
      panecmd.setStyle("-fx-background-color:#6fddbd");
      paneclient.setStyle("-fx-background-color:#6fddbd");
      panefournisseur.setStyle("-fx-background-color:#6fddbd");
      paneproduit.setStyle("-fx-background-color:#ffffff");
      panecat.setStyle("-fx-background-color:#6fddbd");
      panestock.setStyle("-fx-background-color:#6fddbd");
      
      System.out.println("Click sur bouton open produit"); 
    }
    @FXML
    private void openCatContent()throws IOException{
      Parent parent = FXMLLoader.load(getClass()
             .getResource("basecategorie.fxml"));
      panelcentral.getChildren().setAll(parent);
      
      panefacture.setStyle("-fx-background-color:#6fddbd;");
      panecmd.setStyle("-fx-background-color:#6fddbd");
      paneclient.setStyle("-fx-background-color:#6fddbd");
      panefournisseur.setStyle("-fx-background-color:#6fddbd");
      paneproduit.setStyle("-fx-background-color:#6fddbd");
      panecat.setStyle("-fx-background-color:#ffffff");
      panestock.setStyle("-fx-background-color:#6fddbd");
      System.out.println("Click sur bouton open categorie"); 
    }
    @FXML
    private void openStockContent()throws IOException{
      Parent parent = FXMLLoader.load(getClass()
             .getResource("basestock.fxml"));
      panelcentral.getChildren().setAll(parent);
      
      panefacture.setStyle("-fx-background-color:#6fddbd;");
      panecmd.setStyle("-fx-background-color:#6fddbd");
      paneclient.setStyle("-fx-background-color:#6fddbd");
      panefournisseur.setStyle("-fx-background-color:#6fddbd");
      paneproduit.setStyle("-fx-background-color:#6fddbd");
      panecat.setStyle("-fx-background-color:#6fddbd");
      panestock.setStyle("-fx-background-color:#ffffff");
      
      System.out.println("Click sur bouton open stock"); 
    }
    
    @FXML
    private void switchToSecondary() throws IOException {
       // App.setRoot("secondary");
       Categorie cat1 = new Categorie();
       cat1.setNom("ORDINATEUR");
       
       categorieDao.save(cat1);
       
       Categorie cat2 = new Categorie();
       cat2.setNom("HABIT POUR FEMME CLAIRE");
       
       categorieDao.save(cat2);
       
       Categorie cat3 = new Categorie();
       cat3.setNom("BIJOUX");
       
       categorieDao.save(cat3);
       
       /*categorieDao.getAll().forEach(c->{
           System.out.println("Cat 1 : "+c.getNom());
       });*/
       
       Categorie c4 = categorieDao.findById(5L);
       System.out.println("Cat : "+c4.getNom());
       
        /*Fournisseur f = new Fournisseur();
        f.setNom("STEPHANE");
        f.setNumTel("0978224451");
        f.setAdresse("Kassapa");
        
        fournisseurDao.save(f);*/
        fournisseurDao.getAll().forEach(fu->{
            System.out.println("Fournisseur : "+fu.getNom());
        });
       
     //  categorieDao.delete(c4);
      /* Produit p = new Produit();
       
       p.setLibelle("LENOVO");
       p.setPrix(800.0);
       p.setDateExp(new Date());
       p.setDateFab(new Date());
       p.setCategorie(c4);
       p.setFournisseurs(fournisseurDao.getAll());
       
       produitDao.save(p);*/
      /* Produit p1 = produitDao.findById(1L);
       System.out.println("Prod : "+p1.getLibelle());
       System.out.println("Prod Cat : "+p1.getCategorie().getNom());
       System.out.println("Prod Prix: "+p1.getPrix());
       
       produitDao.getAll().forEach(prod->{
           prod.getFournisseurs().forEach(fourn->{
           System.out.println("Prod Fournisseur: "+fourn.getNom());
       });
       });
    */
       
       
    }
}
