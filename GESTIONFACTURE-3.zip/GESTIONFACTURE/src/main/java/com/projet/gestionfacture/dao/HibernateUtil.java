/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.projet.gestionfacture.dao;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Cimanuka
 */
public class HibernateUtil {
    
    private static final EntityManagerFactory emf = 
            Persistence.createEntityManagerFactory("default");
    
    public static EntityManager getEntityManager(){
        return emf.createEntityManager();
    }
}
