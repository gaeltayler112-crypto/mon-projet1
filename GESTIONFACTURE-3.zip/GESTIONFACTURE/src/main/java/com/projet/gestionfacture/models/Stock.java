/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.projet.gestionfacture.models;

import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

/**
 *
 * @author Cimanuka
 */
@Entity
public class Stock {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int quantiteEnStock;
    private Date dateDerniereEntree;
    private Date dateDerniereSortie;
    private int seuilAlerte;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "prod_id")
    private Produit produit;

    public Stock() {
    }

    public Stock(Long id, int quantiteEnStock, Date dateDerniereEntree, Date dateDerniereSortie, int seuilAlerte, Produit produit) {
        this.id = id;
        this.quantiteEnStock = quantiteEnStock;
        this.dateDerniereEntree = dateDerniereEntree;
        this.dateDerniereSortie = dateDerniereSortie;
        this.seuilAlerte = seuilAlerte;
        this.produit = produit;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getQuantiteEnStock() {
        return quantiteEnStock;
    }

    public void setQuantiteEnStock(int quantiteEnStock) {
        this.quantiteEnStock = quantiteEnStock;
    }

    public Date getDateDerniereEntree() {
        return dateDerniereEntree;
    }

    public void setDateDerniereEntree(Date dateDerniereEntree) {
        this.dateDerniereEntree = dateDerniereEntree;
    }

    public Date getDateDerniereSortie() {
        return dateDerniereSortie;
    }

    public void setDateDerniereSortie(Date dateDerniereSortie) {
        this.dateDerniereSortie = dateDerniereSortie;
    }

    public int getSeuilAlerte() {
        return seuilAlerte;
    }

    public void setSeuilAlerte(int seuilAlerte) {
        this.seuilAlerte = seuilAlerte;
    }

    public Produit getProduit() {
        return produit;
    }

    public void setProduit(Produit produit) {
        this.produit = produit;
    }

    
            
}
