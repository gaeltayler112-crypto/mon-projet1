/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.projet.gestionfacture.dao;

import com.projet.gestionfacture.models.Produit;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author Cimanuka
 */
public class ProduitDao {
    
    public void save(Produit p){
        EntityManager em = HibernateUtil.getEntityManager();
        em.getTransaction().begin();
        em.merge(p);
        em.getTransaction().commit();
        em.close();
    }
    public List<Produit>getAll(){
        EntityManager em = HibernateUtil.getEntityManager();
        return em.createQuery("from Produit",Produit.class).getResultList();
    }
    public void delete(Produit p){
        EntityManager em = HibernateUtil.getEntityManager();
        em.getTransaction().begin();
        em.remove(em.merge(p));
        em.getTransaction().commit();
        em.close();
    }
    public Produit findById(Long id){
        EntityManager em = HibernateUtil.getEntityManager();
        Produit p = em.find(Produit.class,id);
        em.close();
        return p;
    }
}
