/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.projet.gestionfacture;

import com.projet.gestionfacture.dao.ClientDao;
import com.projet.gestionfacture.models.Client;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

/**
 *
 * @author Cimanuka
 */
public class DialogAddClientController 
        implements  Initializable{
 
    @FXML
    private TextField zoneNom;
    @FXML
    private TextField zoneAdresse;
    @FXML
    private TextField zoneNumTel;
    
    private final ClientDao clientDao = 
            new ClientDao();
    
    @Override
    public void initialize(URL url, 
            ResourceBundle rb) {
        System.out.println("Chargement de l "
                + "interface dialog add client fxml");
    }
    
    @FXML
    private void saveClient(){
        
        Client cl = new Client();
        cl.setNom(zoneNom.getText());
        cl.setAdresse(zoneAdresse.getText());
        cl.setNumTel(zoneNumTel.getText());
        
        System.out.println("NOM : "+cl.getNom());
        
        if(clientDao.save(cl)!=null){
            Alert alert = new Alert
            (Alert.AlertType.INFORMATION);
            alert.setTitle("Save Client");
            alert.setHeaderText(null);
            alert.setContentText("Client enregistré avec succes");
            alert.showAndWait();
        }
        else{
            Alert alert = new Alert
            (Alert.AlertType.INFORMATION);
            alert.setTitle("Save Client");
            alert.setHeaderText(null);
            alert.setContentText("L'enregistrement du client a échoué");
            alert.showAndWait();
        }
    }
    
    
}
