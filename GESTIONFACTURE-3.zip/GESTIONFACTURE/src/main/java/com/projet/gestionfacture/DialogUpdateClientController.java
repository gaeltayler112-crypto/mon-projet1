/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.projet.gestionfacture;

import com.projet.gestionfacture.dao.ClientDao;
import com.projet.gestionfacture.models.Client;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

/**
 *
 * @author Cimanuka
 */
public class DialogUpdateClientController 
        implements Initializable{
    
    @FXML
    private TextField zoneNom;
    @FXML
    private TextField zoneAdresse;
    @FXML
    private TextField zoneNumTel;
    
    private final ClientDao clientDao = 
            new ClientDao();
    
    private Client client;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }
    
    public void setClient(Client cl)
    {
       this.client = cl; 
       zoneNom.setText(client.getNom());
       zoneAdresse.setText(client.getAdresse());
       zoneNumTel.setText(client.getNumTel());
    }
    @FXML
    private void saveClient(){
        
        client.setNom(zoneNom.getText());
        client.setAdresse(zoneAdresse.getText());
        client.setNumTel(zoneNumTel.getText());
        
        System.out.println("NOM : "+client.getNom());
        
        if(clientDao.save(client)!=null){
            Alert alert = new Alert
            (Alert.AlertType.INFORMATION);
            alert.setTitle("Save Client");
            alert.setHeaderText(null);
            alert.setContentText("Client enregistré avec succes");
            alert.showAndWait();
        }
        else{
            Alert alert = new Alert
            (Alert.AlertType.INFORMATION);
            alert.setTitle("Save Client");
            alert.setHeaderText(null);
            alert.setContentText("L'enregistrement du client a échoué");
            alert.showAndWait();
        }
    }
}
