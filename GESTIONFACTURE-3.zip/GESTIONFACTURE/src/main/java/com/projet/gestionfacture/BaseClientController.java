/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.projet.gestionfacture;

import com.projet.gestionfacture.dao.ClientDao;
import com.projet.gestionfacture.models.Client;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author Cimanuka
 */
public class BaseClientController 
        implements Initializable{
    
    private final ClientDao clientDao = new ClientDao();
    
    @FXML
    private TableView<Client> tableClient;
    
    @FXML
    private TableColumn<Client,Long> colId;
    @FXML
    private TableColumn<Client,String> colNom;
    @FXML
    private TableColumn<Client,String> colAdresse;
    @FXML
    private TableColumn<Client,String> colNum;
    
    @Override
    public void initialize(URL url, 
            ResourceBundle rb) {
     
        System.out.println("Chargement de l "
                + "interface base client fxml");
    
        colId.setCellValueFactory
        (data->new ReadOnlyObjectWrapper<>
        (data.getValue().getId()));
        
        colNom.setCellValueFactory
        (data->new ReadOnlyObjectWrapper<>
        (data.getValue().getNom()));
        
        colAdresse.setCellValueFactory
        (data->new ReadOnlyObjectWrapper<>
        (data.getValue().getAdresse()));
        
        colNum.setCellValueFactory
        (data->new ReadOnlyObjectWrapper<>
        (data.getValue().getNumTel()));
        
        refreshTable();
    }

    private void refreshTable(){
        tableClient.setItems(FXCollections.observableArrayList(clientDao.getAll()));
    }
    
    @FXML
    private void openDialogAddClient() throws IOException{
        
        FXMLLoader loader = new FXMLLoader(PrimaryController.class.getResource("dialogAddClient.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(loader.load()));
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.showAndWait();
        
        refreshTable();
    }
    
    @FXML
    private void deleteClient(){
       Client clientSelect = tableClient
               .getSelectionModel().getSelectedItem();
    
       if(clientSelect!=null){
           Alert alert = new Alert
        (Alert.AlertType.CONFIRMATION);
           alert.setTitle("Confirmation");
           alert.setHeaderText("voulez-vous supprimer ?");
           alert.setContentText("Choisissez une option");
           
           Optional<ButtonType> result = alert.showAndWait();
           
           if(result.isPresent() && result.get()==ButtonType.OK)
           {
               clientDao.delete(clientSelect);
               refreshTable();
           }
       }
    
    }
    
    @FXML
    private void updateClient() throws IOException{
        Client clientSelect = tableClient
        .getSelectionModel().getSelectedItem();
        
        if(clientSelect != null){
            Alert alert = new Alert
        (Alert.AlertType.CONFIRMATION);
         alert.setTitle("Confirmation");
         alert.setHeaderText("voulez-vous modifier?");
         alert.setContentText("Choisissez une option");
         
         Optional<ButtonType> result = alert.showAndWait();
         
         if(result.isPresent() && result.get()==ButtonType.OK)
         {
            FXMLLoader loader = new FXMLLoader
            (PrimaryController.class.getResource
            ("dialogUpdateClient.fxml"));
            
            Stage stage = new Stage();
            stage.setScene(new Scene(loader.load()));
            DialogUpdateClientController ctrl = 
                    loader.getController();
            ctrl.setClient(clientSelect);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();
            
            refreshTable();
         }
    }
    }
    
}
