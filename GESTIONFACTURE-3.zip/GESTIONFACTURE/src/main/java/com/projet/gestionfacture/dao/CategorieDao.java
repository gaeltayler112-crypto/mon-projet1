/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.projet.gestionfacture.dao;

import com.projet.gestionfacture.models.Categorie;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author Cimanuka
 */
public class CategorieDao {
    
    public void save(Categorie c){
        EntityManager em = HibernateUtil.getEntityManager();
        em.getTransaction().begin();
        em.merge(c);
        em.getTransaction().commit();
        em.close();
    }
    
    public List<Categorie> getAll(){
        EntityManager em = HibernateUtil.getEntityManager();
        return em.createQuery("from Categorie",Categorie.class).getResultList();    
    }
    
    public void delete(Categorie c){
        EntityManager em = HibernateUtil.getEntityManager();
        em.getTransaction().begin();
        em.remove(em.merge(c));
        em.getTransaction().commit();
        em.close();
    }
    
    public Categorie findById(Long id){
        EntityManager em = HibernateUtil.getEntityManager();
        Categorie c = em.find(Categorie.class, id);
        em.close();
        return c;
    }
}
