/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.projet.gestionfacture.dao;

import com.projet.gestionfacture.models.Client;
import java.util.List;
import javax.persistence.EntityManager;

/**
 *
 * @author Cimanuka
 */
public class ClientDao {
    
    public Client save(Client p){
        Client client;
        EntityManager em = HibernateUtil.getEntityManager();
        em.getTransaction().begin();
        client = em.merge(p);
        em.getTransaction().commit();
        em.close();
        return client;
    }
    public List<Client>getAll(){
        EntityManager em = HibernateUtil.getEntityManager();
        return em.createQuery("from Client",Client.class).getResultList();
    }
    public void delete(Client c){
        EntityManager em = HibernateUtil.getEntityManager();
        em.getTransaction().begin();
        em.remove(em.merge(c));
        em.getTransaction().commit();
        em.close();
    }
    public Client findById(Long id){
        EntityManager em = HibernateUtil.getEntityManager();
        Client c = em.find(Client.class,id);
        em.close();
        return c;
    }
}
